import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../blocs/subject_bloc.dart';
import '../models/subject.dart';

class SubjectView extends StatefulWidget {
  @override
  _SubjectViewState createState() => _SubjectViewState();
}

class _SubjectViewState extends State<SubjectView> {
  final _nameController = TextEditingController();
  final _scheduleController = TextEditingController();
  final _gradeController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Gestor de Materias'),
      ),
      body: BlocBuilder<SubjectBloc, SubjectState>(
        builder: (context, state) {
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                TextField(
                  controller: _nameController,
                  decoration:
                      InputDecoration(labelText: 'Nombre de la Materia'),
                ),
                TextField(
                  controller: _scheduleController,
                  decoration: InputDecoration(labelText: 'Horario'),
                ),
                TextField(
                  controller: _gradeController,
                  decoration: InputDecoration(labelText: 'Nota'),
                  keyboardType: TextInputType.number,
                ),
                SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () {
                    final name = _nameController.text;
                    final schedule = _scheduleController.text;
                    final grade = double.tryParse(_gradeController.text) ?? 0.0;

                    if (name.isNotEmpty && schedule.isNotEmpty) {
                      final subject =
                          Subject(name: name, schedule: schedule, grade: grade);
                      context.read<SubjectBloc>().add(AddSubject(subject));
                    }
                  },
                  child: Text('Agregar Materia'),
                ),
                SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () {
                    context.read<SubjectBloc>().add(CalculateAverage());
                  },
                  child: Text('Calcular Promedio'),
                ),
                SizedBox(height: 16),
                if (state is SubjectLoaded) ...[
                  Text('Promedio: ${state.average.toStringAsFixed(2)}'),
                  Expanded(
                    child: ListView.builder(
                      itemCount: state.subjects.length,
                      itemBuilder: (context, index) {
                        final subject = state.subjects[index];
                        return ListTile(
                          title: Text(subject.name),
                          subtitle: Text(
                              'Horario: ${subject.schedule} - Nota: ${subject.grade}'),
                        );
                      },
                    ),
                  ),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}
