class Subject {
  final String name;
  final String schedule;
  final double grade;

  Subject({
    required this.name,
    required this.schedule,
    required this.grade,
  });
}
