part of 'subject_bloc.dart';

abstract class SubjectEvent extends Equatable {
  const SubjectEvent();

  @override
  List<Object?> get props => [];
}

class AddSubject extends SubjectEvent {
  final Subject subject;

  const AddSubject(this.subject);

  @override
  List<Object?> get props => [subject];
}

class CalculateAverage extends SubjectEvent {}
