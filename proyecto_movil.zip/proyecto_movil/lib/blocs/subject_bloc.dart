import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import '../models/subject.dart';

part 'subject_event.dart';
part 'subject_state.dart';

class SubjectBloc extends Bloc<SubjectEvent, SubjectState> {
  SubjectBloc() : super(SubjectInitial()) {
    on<AddSubject>((event, emit) {
      final updatedSubjects = List<Subject>.from(state.subjects)
        ..add(event.subject);
      emit(SubjectLoaded(updatedSubjects));
    });

    on<CalculateAverage>((event, emit) {
      if (state.subjects.isEmpty) {
        emit(SubjectLoaded([], average: 0));
      } else {
        final total =
            state.subjects.fold(0.0, (sum, subject) => sum + subject.grade);
        final average = total / state.subjects.length;
        emit(SubjectLoaded(state.subjects, average: average));
      }
    });
  }
}
