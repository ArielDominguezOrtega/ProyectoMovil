part of 'subject_bloc.dart';

abstract class SubjectState extends Equatable {
  final List<Subject> subjects;
  final double average;

  const SubjectState({this.subjects = const [], this.average = 0});

  @override
  List<Object?> get props => [subjects, average];
}

class SubjectInitial extends SubjectState {}

class SubjectLoaded extends SubjectState {
  const SubjectLoaded(List<Subject> subjects, {double average = 0})
      : super(subjects: subjects, average: average);
}
